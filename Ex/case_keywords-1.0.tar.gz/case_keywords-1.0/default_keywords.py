# Author: Tan Jun
# update: 2020 10 15

import case_writer
import traceback

writer = case_writer.writer

func_type = 'public'

def setup():
    writer('status', traceback.extract_stack()[-2][1], '', '', {})
    return None

def step():
    writer('status', traceback.extract_stack()[-2][1], '', '', {})
    return None

def teardown():
    writer('status', traceback.extract_stack()[-2][1], '', '', {})
    return None

def save_data(from_obj, data_name, key_name):
    writer(func_type, traceback.extract_stack()[-2][1], '__public__', '', locals())
    return None

def wait_seconds(seconds):
    writer(func_type, traceback.extract_stack()[-2][1], '__public__', '', locals())
    return None

def make_dir(dst_path, dir_name, is_assert):
    writer(func_type, traceback.extract_stack()[-2][1], '__public__', is_assert, locals())
    return None

def make_file(dst_path, file_name, file_input, is_assert):
    writer(func_type, traceback.extract_stack()[-2][1], '__public__', is_assert, locals())
    return None

def input_file(dst_path, file_name, file_input, is_assert):
    writer(func_type, traceback.extract_stack()[-2][1], '__public__', is_assert, locals())
    return None

def remove(dst_path, dst_name, dst_type, is_assert):
    writer(func_type, traceback.extract_stack()[-2][1], '__public__', is_assert, locals())
    return None

def get_dir_info(dst_path, is_assert):
    writer(func_type, traceback.extract_stack()[-2][1], '__public__', is_assert, locals())
    return None

def find_from_info(dir_info, dst_name, is_assert):
    writer(func_type, traceback.extract_stack()[-2][1], '__public__', is_assert, locals())
    return None