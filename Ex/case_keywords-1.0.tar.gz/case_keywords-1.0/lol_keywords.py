import case_writer
import traceback

writer = case_writer.writer

func_type = 'lol'

def make_order(obj_name, is_assert='1'):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None

def getCourseInfo(
    obj_name, 
    courseId, 
    cancel_key='', 
    cancel_data_key='', 
    appKey='SUN001', 
    module='explosive',
    method='getCourseInfo',
    timestamp='TIME_STR_01',
    requestId='1234567890', 
    sign='TEST_SIGN',    
    is_assert='1'
):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None

def getCourseSaleStatus(
    obj_name, 
    courseId, 
    cancel_key='', 
    cancel_data_key='',  
    appKey='SUN001', 
    module='explosive',
    method='getCourseSaleStatus',
    timestamp='TIME_STR_01',
    requestId='1234567890', 
    sign='TEST_SIGN',   
    is_assert='1'
):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None

def canBuyCourse(
    obj_name, 
    courseId, 
    mobile, 
    cancel_key='', 
    cancel_data_key='', 
    appKey='SUN001', 
    module='explosive',
    method='canBuyCourse',
    timestamp='TIME_STR_01',
    requestId='1234567890', 
    sign='TEST_SIGN',  
    is_assert='1'
):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None

def orderCreate(
    obj_name, 
    courseId, 
    mobile, 
    createTime,
    address_name,
    address_moblie,
    address_province,
    address_city,
    address_area,
    address_address,
    cancel_key='', 
    cancel_data_key='', 
    cancel_address_key='',
    orderNo='', 
    appKey='SUN001', 
    module='explosive',
    method='orderCreate',
    timestamp='TIME_STR_01',
    requestId='1234567890', 
    sign='TEST_SIGN',  
    is_assert='1'
):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None

def orderCancel(
    obj_name, 
    cancel_key='', 
    cancel_data_key='', 
    orderNo='', 
    appKey='SUN001', 
    module='explosive',
    method='orderCancel',
    timestamp='TIME_STR_01',
    requestId='1234567890', 
    sign='TEST_SIGN',  
    is_assert='1'
):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None

def orderSuccess(
    obj_name, 
    payTime, 
    cancel_key='', 
    cancel_data_key='', 
    orderNo='', 
    appKey='SUN001', 
    module='explosive',
    method='orderSuccess',
    timestamp='TIME_STR_01',
    requestId='1234567890', 
    sign='TEST_SIGN',  
    is_assert='1'
):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None