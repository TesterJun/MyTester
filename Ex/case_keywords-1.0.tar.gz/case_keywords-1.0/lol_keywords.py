import case_writer
import traceback

writer = case_writer.writer

func_type = 'lol'

def getCourseInfo(
    obj_name, 
    courseId, 
    cancel_key='', 
    cancel_bizdata_key='', 
    appKey='SUN001', 
    module='explosive',
    method='getCourseInfo',
    requestId='1234567890', 
    sign='TEST_SIGN',    
    is_assert='1'
):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None

def getCourseSaleStatus(
    obj_name, 
    courseId, 
    cancel_key='', 
    cancel_bizdata_key='',  
    appKey='SUN001', 
    module='explosive',
    method='getCourseSaleStatus',
    requestId='1234567890', 
    sign='TEST_SIGN',   
    is_assert='1'
):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None

def canBuyCourse(
    obj_name, 
    courseId, 
    mobile, 
    cancel_key='', 
    cancel_bizdata_key='', 
    appKey='SUN001', 
    module='explosive',
    method='canBuyCourse',
    requestId='1234567890', 
    sign='TEST_SIGN',  
    is_assert='1'
):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None

def orderCreate(
    obj_name, 
    courseId, 
    mobile, 
    orderNo, 
    createTime,
    address_name,
    address_moblie,
    address_province,
    address_city,
    address_area,
    address_address,
    cancel_key='', 
    cancel_bizdata_key='', 
    cancel_address_key='',
    appKey='SUN001', 
    module='explosive',
    method='orderCreate',
    requestId='1234567890', 
    sign='TEST_SIGN',  
    is_assert='1'
):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None

def orderCancel(
    obj_name, 
    orderNo, 
    cancel_key='', 
    cancel_bizdata_key='', 
    appKey='SUN001', 
    module='explosive',
    method='orderCancel',
    requestId='1234567890', 
    sign='TEST_SIGN',  
    is_assert='1'
):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None

def orderSuccess(
    obj_name, 
    orderNo, 
    payTime, 
    cancel_key='', 
    cancel_bizdata_key='', 
    appKey='SUN001', 
    module='explosive',
    method='orderSuccess',
    requestId='1234567890', 
    sign='TEST_SIGN',  
    is_assert='1'
):
    writer(func_type, traceback.extract_stack()[-2][1], obj_name, is_assert, locals())
    return None