from distutils.core import setup

setup(
    name='case_keywords',
    version='1.0',
    description='My Tester Step Keywords',
    author='Jun',
    author_email='heartnec@126.com',
    url='',
    py_modules=[
        '__init__',
        'default_keywords', 
        'lol_keywords',
        'case_writer', 
    ]
)