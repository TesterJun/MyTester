# Author: Jun
# update: 2020 09 30

import traceback
import os
import sys

def writer(func_type, func_line, obj_name, is_assert, func_data):
    parm = {}
    for key, value in func_data.items():
        if (
            key == 'is_assert' or 
            key == 'obj_name' or
            not isinstance(value, str)
        ):
            continue
        parm[key] = value

    words = {
        'type': func_type,
        'action': traceback.extract_stack()[-2][2],
        'line': func_line,
        'obj_name': obj_name,
        'is_assert': is_assert,
        'parm': parm
    }
    case_path = os.path.realpath(sys.argv[0]).replace('\\', '/')
    for path in ['test', 'fail']:
        path = '/Case/case_%s' % path
        if path not in case_path:
            continue

        word_path = case_path.replace(path, '/Case/case_word').replace('.py', '.word')
        with open(word_path, 'a+') as f:
            f.write(str(words) + '\n')
        break
    return None